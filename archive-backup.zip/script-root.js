// archived root script.js
